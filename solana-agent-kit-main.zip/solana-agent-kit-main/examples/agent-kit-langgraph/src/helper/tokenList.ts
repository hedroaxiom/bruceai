export const tokenList = [
  {
    name: "USDC",
    ticker: "USDC",
    decimal: 6,
    mintAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  },
  {
    name: "USDT",
    ticker: "USDT",
    decimal: 6,
    mintAddress: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
  },
  {
    name: "USDS",
    ticker: "USDS",
    decimal: 6,
    mintAddress: "USDSwr9ApdHk5bvJKMjzff41FfuX8bSxdKcR81vTwcA",
  },
  {
    name: "SOL",
    ticker: "SOL",
    decimal: 9,
    mintAddress: "So11111111111111111111111111111111111111112",
  },
  {
    name: "jitoSOL",
    ticker: "jitoSOL",
    decimal: 9,
    mintAddress: "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn",
  },
  {
    name: "bSOL",
    ticker: "bSOL",
    decimal: 9,
    mintAddress: "bSo13r4TkiE4KumL71LsHTPpL2euBYLFx6h9HP3piy1",
  },
  {
    name: "mSOL",
    ticker: "mSOL",
    decimal: 9,
    mintAddress: "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",
  },
  {
    name: "BONK",
    ticker: "BONK",
    decimal: 9,
    mintAddress: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  },
];
